package com.anncode.notificacionfirebase.RestAPI;

/**
 * Created by anahisalgado on 09/06/16.
 */
public final class ConsantesRestAPI {
    public static final String ROOT_URL = "https://afternoon-lowlands-49612.herokuapp.com/";
    public static final String KEY_POST_ID_TOKEN = "token-device/";
    public static final String KEY_TOQUE_ANIMAL = "toque-animal/{id}/{animal}/";


}
